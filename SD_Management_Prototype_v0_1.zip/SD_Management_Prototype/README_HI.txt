SD Management — Prototype v0.1
================================

यह शुरुआती responsive web-app prototype है।

कैसे चलाएँ:
1. ZIP extract करें।
2. index.html को Chrome/Edge में खोलें।
3. Add Site से demo site जोड़ें।
4. Daily Entry / Weekly Reading में records डालें।
5. Reports में CSV export और JSON backup आज़माएँ।

क्या शामिल है:
- Hindi/English-friendly responsive interface
- Light/Dark theme
- Site Master fields: SAP ID, Site Name, Account No., Latitude/Longitude,
  DG tank capacity, reading interval और assigned members
- SAP ID search; Card/Table list toggle
- Daily entry, weekly reading और diesel consumption calculation
- Basic due-status display, recent entries
- CSV export, JSON backup और restore confirmation
- Basic PWA manifest/service worker files

महत्वपूर्ण सीमा:
यह केवल local browser prototype है। Data उसी browser/device के local storage में
रहता है। इसमें अभी वास्तविक login/password, OTP, secure role permissions, cloud
server/database, cloud sync, server-side audit trail, robust offline sync/conflict
handling, push notification, GPS distance validation, Excel (.xlsx) या PDF export
नहीं हैं। इसे अभी production या वास्तविक operational site data के लिए इस्तेमाल न करें।
Browser data हटने पर demo records खो सकते हैं; backup अलग से डाउनलोड रखें।
अगले चरण में backend, authentication, database, permissions, audit, sync और security
जोड़कर इसे production-ready बनाया जाना चाहिए।
